module.exports = {
    database: {
        username: "root",
        password: "gOSA1357",
        database: "classicmodels",
        host: "localhost",
    }
} 